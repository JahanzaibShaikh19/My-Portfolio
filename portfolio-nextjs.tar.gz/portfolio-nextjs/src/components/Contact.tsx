"use client";

import { useState } from "react";
import Image from "next/image";
import { contactInfo } from "@/data/content";
import SectionTitle from "./SectionTitle";
import RevealOnScroll from "./RevealOnScroll";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.MouseEvent) => {
    e.preventDefault();
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setStatus("success");
        setForm({ name: "", email: "", subject: "", message: "" });
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="contact" className="py-16">
      {/* Background image strip */}
      <div className="relative h-48 md:h-64 w-full overflow-hidden mb-0">
        <Image
          src="/images/bg.jpg"
          alt="Contact background"
          fill
          className="object-cover opacity-30"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black" />
      </div>

      <div className="px-6 md:px-10 lg:px-16 pt-12">
        <RevealOnScroll variant="scale">
          <SectionTitle>Get In Touch</SectionTitle>
        </RevealOnScroll>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-12 lg:gap-20">
          {/* Form */}
          <RevealOnScroll>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Name"
                className="contact-input"
              />
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="Email"
                className="contact-input"
              />
            </div>
            <input
              type="text"
              name="subject"
              value={form.subject}
              onChange={handleChange}
              placeholder="Subject"
              className="contact-input mb-4"
            />
            <textarea
              name="message"
              value={form.message}
              onChange={handleChange}
              rows={6}
              placeholder="Message"
              className="contact-input mb-6"
            />
            <button
              onClick={handleSubmit}
              disabled={status === "sending"}
              className="px-8 py-3 bg-accent text-black text-sm font-semibold rounded-full
                         hover:bg-white transition-colors duration-200 disabled:opacity-50"
            >
              {status === "sending" ? "Sending…" : "Send Message"}
            </button>
            {status === "success" && (
              <p className="mt-4 text-sm text-accent">
                ✓ Message sent! I&apos;ll get back to you soon.
              </p>
            )}
            {status === "error" && (
              <p className="mt-4 text-sm text-red-400">
                Something went wrong. Please try again.
              </p>
            )}
          </RevealOnScroll>

          {/* Contact details */}
          <RevealOnScroll delay={200}>
            <div className="flex flex-col gap-6">
              <div>
                <h6 className="text-xs uppercase tracking-widest text-white/40 mb-1">
                  Address
                </h6>
                <p className="!text-sm !opacity-90 !leading-relaxed">
                  {contactInfo.addressLine1}
                  <br />
                  {contactInfo.addressLine2}
                </p>
              </div>
              <div>
                <h6 className="text-xs uppercase tracking-widest text-white/40 mb-1">
                  Email
                </h6>
                <a
                  href={`mailto:${contactInfo.email}`}
                  className="text-sm text-white/90 hover:text-accent transition-colors"
                >
                  {contactInfo.email}
                </a>
              </div>
              <div>
                <h6 className="text-xs uppercase tracking-widest text-white/40 mb-3">
                  Social
                </h6>
                <ul className="flex flex-wrap gap-4">
                  {contactInfo.socials.map((s) => (
                    <li key={s.label}>
                      <a
                        href={s.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-white/70 hover:text-accent transition-colors"
                      >
                        {s.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </RevealOnScroll>
        </div>
      </div>
    </section>
  );
}
