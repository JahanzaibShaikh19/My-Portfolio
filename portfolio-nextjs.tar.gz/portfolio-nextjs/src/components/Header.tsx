"use client";

import { useEffect, useState } from "react";

const NAV_ITEMS = [
  { id: "home", label: "Home" },
  { id: "resume", label: "Resume" },
  { id: "portfolio", label: "Portfolio" },
  { id: "blog", label: "Blog" },
  { id: "contact", label: "Contact" },
];

export default function Header() {
  const [activeSection, setActiveSection] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const sections = NAV_ITEMS.map((item) =>
      document.getElementById(item.id)
    ).filter((el): el is HTMLElement => el !== null);

    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    id: string
  ) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setActiveSection(id);
    setMenuOpen(false);
  };

  return (
    <header className="fixed top-6 right-6 md:top-8 md:right-10 z-50 flex flex-col items-end gap-4">
      {/* Hamburger */}
      <button
        aria-label="Toggle navigation"
        onClick={() => setMenuOpen((v) => !v)}
        className="w-11 h-11 rounded-full bg-white flex items-center justify-center relative shrink-0"
      >
        <span className="relative block w-5 h-[10px]">
          <span
            className={`absolute left-0 right-0 top-0 h-[2px] bg-black transition-all duration-300 ${
              menuOpen ? "rotate-45 translate-y-[4px]" : ""
            }`}
          />
          <span
            className={`absolute left-0 right-0 bottom-0 h-[2px] bg-black transition-all duration-300 ${
              menuOpen ? "-rotate-45 -translate-y-[4px]" : ""
            }`}
          />
        </span>
      </button>

      {/* Nav links */}
      <nav
        className={`flex flex-col items-end gap-2 md:gap-3 transition-all duration-300 ${
          menuOpen
            ? "opacity-100 translate-x-0"
            : "opacity-0 translate-x-6 pointer-events-none md:opacity-100 md:translate-x-0 md:pointer-events-auto"
        }`}
      >
        <ul className="flex flex-col items-end gap-1.5 md:gap-2 bg-black/40 md:bg-transparent backdrop-blur-md md:backdrop-blur-none rounded-2xl px-5 py-4 md:p-0">
          {NAV_ITEMS.map((item) => (
            <li key={item.id}>
              <a
                href={`#${item.id}`}
                onClick={(e) => handleNavClick(e, item.id)}
                className={`text-sm md:text-base font-medium transition-colors duration-200 ${
                  activeSection === item.id
                    ? "text-accent line-through"
                    : "text-white/80 hover:text-white"
                }`}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
